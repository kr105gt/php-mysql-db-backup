--
-- Database : idcspV2
--
-- --------------------------------------------------
-- ---------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;
--
-- Tabel structure for table `tabAlumnoInscripcion`
--
DROP TABLE  IF EXISTS `tabAlumnoInscripcion`;
CREATE TABLE `tabAlumnoInscripcion` (
  `Id_Alumno` int(11) NOT NULL AUTO_INCREMENT,
  `Cod_Personal` varchar(20) COLLATE latin1_spanish_ci DEFAULT NULL,
  `Fecha_Inscripcion` date DEFAULT NULL,
  `Nombre` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `Apellido` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `Id_Genero` int(11) NOT NULL,
  `Fecha_Nacimiento` date NOT NULL,
  `Id_Encargado` int(11) NOT NULL,
  `Fotografia` varchar(50) COLLATE latin1_spanish_ci DEFAULT NULL,
  `Observaciones` varchar(100) COLLATE latin1_spanish_ci DEFAULT NULL,
  PRIMARY KEY (`Id_Alumno`),
  KEY `Id_Encargado` (`Id_Encargado`),
  KEY `Id_Genero` (`Id_Genero`),
  CONSTRAINT `tabAlumnoInscripcion_ibfk_1` FOREIGN KEY (`Id_Encargado`) REFERENCES `tabEncargado` (`Id_Encargado`),
  CONSTRAINT `tabAlumnoInscripcion_ibfk_2` FOREIGN KEY (`Id_Genero`) REFERENCES `tabGenero` (`Id_Genero`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

INSERT INTO `tabAlumnoInscripcion`  VALUES ( "1","EDUC8701","2014-05-06","Carlos Manuel","Buitrago Poveda","2","1992-05-08","1","","");
INSERT INTO `tabAlumnoInscripcion`  VALUES ( "2","EDUC9000","2014-05-06","Gabriela Maria","Quijano Orozco","1","1992-05-08","2","","");
INSERT INTO `tabAlumnoInscripcion`  VALUES ( "6","EDUC87011","2014-05-17","Jorge Mario","Robles Lopez","2","1995-05-13","10","","");
INSERT INTO `tabAlumnoInscripcion`  VALUES ( "7","EDUC1294","2014-05-17","Gustavo Daniel","Martinez Orozco","2","1996-05-12","9","","");
INSERT INTO `tabAlumnoInscripcion`  VALUES ( "8","EDUC02357","2014-05-23","Luis Alberto","Robles Orozco","2","1995-05-18","10","","");
INSERT INTO `tabAlumnoInscripcion`  VALUES ( "9","EDUC8735","2014-05-23","Cristian Estuardo","Robles Fuentes","2","1996-07-25","10","","");
INSERT INTO `tabAlumnoInscripcion`  VALUES ( "10","EDUC8710","2014-05-23","Juan Carlos","Figuero Lopez","2","1994-05-13","6","","");
INSERT INTO `tabAlumnoInscripcion`  VALUES ( "11","EDUC5901","2014-05-23","Rosa Emilia","Martinez Lopez","1","1996-01-15","9","","Prueba");


--
-- Tabel structure for table `tabAnuncio`
--
DROP TABLE  IF EXISTS `tabAnuncio`;
CREATE TABLE `tabAnuncio` (
  `Id_Anuncio` int(11) NOT NULL AUTO_INCREMENT,
  `Fecha` date NOT NULL,
  `Titulo` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `Mensaje` text COLLATE latin1_spanish_ci NOT NULL,
  `Autor` varchar(100) COLLATE latin1_spanish_ci NOT NULL,
  PRIMARY KEY (`Id_Anuncio`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

INSERT INTO `tabAnuncio`  VALUES ( "1","2014-05-07","probando","probando, probando, 1,2,3","Yo");
INSERT INTO `tabAnuncio`  VALUES ( "2","2014-05-14","asda","asdasd","asd");
INSERT INTO `tabAnuncio`  VALUES ( "3","2014-05-10","xxxxad","dassadsa","Director");
INSERT INTO `tabAnuncio`  VALUES ( "4","2014-05-10","zzzasdsadfas","asdasdq2e2de","Director");
INSERT INTO `tabAnuncio`  VALUES ( "5","2014-05-10","zazazazazaz","zazazazazazaz","Director");
INSERT INTO `tabAnuncio`  VALUES ( "6","2014-05-10","vbvbvbvbv","bvbvbvbvbvb","Manuel Antonio Ballen Vanegas");
INSERT INTO `tabAnuncio`  VALUES ( "7","2014-05-20","123","123","Manuel Antonio Ballen Vanegas");


--
-- Tabel structure for table `tabBitacora`
--
DROP TABLE  IF EXISTS `tabBitacora`;
CREATE TABLE `tabBitacora` (
  `Id_Bitacora` int(11) NOT NULL AUTO_INCREMENT,
  `Transaccion` varchar(100) COLLATE latin1_spanish_ci NOT NULL,
  `Usuario` varchar(100) COLLATE latin1_spanish_ci NOT NULL,
  `Fecha` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `Accion` varchar(100) COLLATE latin1_spanish_ci NOT NULL,
  PRIMARY KEY (`Id_Bitacora`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

INSERT INTO `tabBitacora`  VALUES ( "1","INSERTO","YO","2014-05-22 17:01:50","TO");


--
-- Tabel structure for table `tabCarrera`
--
DROP TABLE  IF EXISTS `tabCarrera`;
CREATE TABLE `tabCarrera` (
  `Id_Carrera` int(11) NOT NULL AUTO_INCREMENT,
  `Nombre` varchar(150) COLLATE latin1_spanish_ci NOT NULL,
  `Estado` tinyint(1) NOT NULL,
  PRIMARY KEY (`Id_Carrera`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

INSERT INTO `tabCarrera`  VALUES ( "1","Bach. Ind. Y Perito con Especialidad en Computacion","1");
INSERT INTO `tabCarrera`  VALUES ( "2","Bach. Ind. Y Perito con Especialidad en Mecanica Automotriz","1");


--
-- Tabel structure for table `tabCatedratico`
--
DROP TABLE  IF EXISTS `tabCatedratico`;
CREATE TABLE `tabCatedratico` (
  `Id_Catedratico` int(11) NOT NULL AUTO_INCREMENT,
  `Nombre` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `Apellido` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `Id_Genero` int(11) NOT NULL,
  `Fecha_Nacimiento` date NOT NULL,
  `Direccion` varchar(100) COLLATE latin1_spanish_ci DEFAULT NULL,
  `Id_Municipio` int(11) NOT NULL,
  `DPI` varchar(20) COLLATE latin1_spanish_ci DEFAULT NULL,
  `Titulo` varchar(50) COLLATE latin1_spanish_ci DEFAULT NULL,
  `Cedula_Docente` varchar(50) COLLATE latin1_spanish_ci DEFAULT NULL,
  `Telefono` int(11) DEFAULT NULL,
  `Estado` tinyint(1) NOT NULL,
  PRIMARY KEY (`Id_Catedratico`),
  KEY `Id_Municipio` (`Id_Municipio`),
  KEY `Id_Genero` (`Id_Genero`),
  CONSTRAINT `tabCatedratico_ibfk_1` FOREIGN KEY (`Id_Municipio`) REFERENCES `tabMunicipio` (`Id_Municipio`),
  CONSTRAINT `tabCatedratico_ibfk_2` FOREIGN KEY (`Id_Genero`) REFERENCES `tabGenero` (`Id_Genero`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

INSERT INTO `tabCatedratico`  VALUES ( "1","Ismael Enrique","Hernandez Nuñez","2","1980-01-10","1a. Calle 1-74 Zona 3","1","4850 85236 1201","Bach. Industrial","CEDULA-DOC-4844","89045175","1");
INSERT INTO `tabCatedratico`  VALUES ( "2","Alvaro Antonio","Hernandez Herrera","2","1975-11-22","2a. Avenida 4-22 Zona 5","2","9856 48054 1201","Bach. Industrial","CEDULA-DOC-9045","77608074","1");
INSERT INTO `tabCatedratico`  VALUES ( "3","Alvaro Antonio","Prieto Nieto","2","1985-07-11","3a. Calle 5-74 Zona 1","4","8452 94058 1203","Bach. Industrial","CEDULA-DOC-8754","84903004","1");
INSERT INTO `tabCatedratico`  VALUES ( "7","Jose Orlando","Lopez Bamaca","2","1975-05-16","6a. Calle 4-58 Zona 2","2","1845 85069 1201","Bach. Industrial","CEDULA-DOC-4872","78960587","1");


--
-- Tabel structure for table `tabCatedraticoUsuario`
--
DROP TABLE  IF EXISTS `tabCatedraticoUsuario`;
CREATE TABLE `tabCatedraticoUsuario` (
  `Id_CatedraticoUsuario` int(11) NOT NULL AUTO_INCREMENT,
  `Id_Usuario` int(11) NOT NULL,
  `Id_Catedratico` int(11) NOT NULL,
  PRIMARY KEY (`Id_CatedraticoUsuario`),
  KEY `Id_Catedratico` (`Id_Catedratico`),
  KEY `Id_Usuario` (`Id_Usuario`),
  CONSTRAINT `tabCatedraticoUsuario_ibfk_1` FOREIGN KEY (`Id_Catedratico`) REFERENCES `tabCatedratico` (`Id_Catedratico`),
  CONSTRAINT `tabCatedraticoUsuario_ibfk_2` FOREIGN KEY (`Id_Usuario`) REFERENCES `tabUsuario` (`Id_Usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

INSERT INTO `tabCatedraticoUsuario`  VALUES ( "1","3","1");
INSERT INTO `tabCatedraticoUsuario`  VALUES ( "2","4","2");
INSERT INTO `tabCatedraticoUsuario`  VALUES ( "3","5","3");
INSERT INTO `tabCatedraticoUsuario`  VALUES ( "4","9","7");


--
-- Tabel structure for table `tabCicloEscolar`
--
DROP TABLE  IF EXISTS `tabCicloEscolar`;
CREATE TABLE `tabCicloEscolar` (
  `Id_CicloEscolar` int(11) NOT NULL AUTO_INCREMENT,
  `Nombre` varchar(25) COLLATE latin1_spanish_ci NOT NULL,
  PRIMARY KEY (`Id_CicloEscolar`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

INSERT INTO `tabCicloEscolar`  VALUES ( "1","2012");
INSERT INTO `tabCicloEscolar`  VALUES ( "2","2013");
INSERT INTO `tabCicloEscolar`  VALUES ( "3","2014");
INSERT INTO `tabCicloEscolar`  VALUES ( "4","2015");


--
-- Tabel structure for table `tabControlEvaluaciones`
--
DROP TABLE  IF EXISTS `tabControlEvaluaciones`;
CREATE TABLE `tabControlEvaluaciones` (
  `Id_ControlEvaluaciones` int(11) NOT NULL AUTO_INCREMENT,
  `Fecha` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `Id_CicloEscolar` int(11) NOT NULL,
  `Id_Evaluacion` int(11) NOT NULL,
  `Id_CursoCatedratico` int(11) NOT NULL,
  PRIMARY KEY (`Id_ControlEvaluaciones`),
  KEY `Id_Evaluacion` (`Id_Evaluacion`),
  KEY `Id_CicloEscolar` (`Id_CicloEscolar`),
  KEY `Id_CursoCatedratico` (`Id_CursoCatedratico`),
  CONSTRAINT `tabControlEvaluaciones_ibfk_1` FOREIGN KEY (`Id_Evaluacion`) REFERENCES `tabEvaluacion` (`Id_Evaluacion`),
  CONSTRAINT `tabControlEvaluaciones_ibfk_2` FOREIGN KEY (`Id_CicloEscolar`) REFERENCES `tabCicloEscolar` (`Id_CicloEscolar`),
  CONSTRAINT `tabControlEvaluaciones_ibfk_3` FOREIGN KEY (`Id_CursoCatedratico`) REFERENCES `tabCursoCatedratico` (`Id_CursoCatedratico`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

INSERT INTO `tabControlEvaluaciones`  VALUES ( "13","2014-05-26 02:55:31","3","1","1");


--
-- Tabel structure for table `tabCurso`
--
DROP TABLE  IF EXISTS `tabCurso`;
CREATE TABLE `tabCurso` (
  `Id_Curso` int(11) NOT NULL AUTO_INCREMENT,
  `Nombre` varchar(100) COLLATE latin1_spanish_ci NOT NULL,
  `Id_Seccion` int(11) NOT NULL,
  `Estado` tinyint(1) NOT NULL,
  PRIMARY KEY (`Id_Curso`),
  KEY `Id_Seccion` (`Id_Seccion`),
  CONSTRAINT `tabCurso_ibfk_1` FOREIGN KEY (`Id_Seccion`) REFERENCES `tabSeccion` (`Id_Seccion`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

INSERT INTO `tabCurso`  VALUES ( "1","Análisis de Sistemas","1","1");
INSERT INTO `tabCurso`  VALUES ( "2","Teoría de la Información","1","1");
INSERT INTO `tabCurso`  VALUES ( "3","Estadistica","1","1");
INSERT INTO `tabCurso`  VALUES ( "4","Contabilidad Integral","1","1");
INSERT INTO `tabCurso`  VALUES ( "5","Fisica","1","1");
INSERT INTO `tabCurso`  VALUES ( "6","Tecnología Vocacional I","1","1");
INSERT INTO `tabCurso`  VALUES ( "7","Dibujo Técnico I","1","1");
INSERT INTO `tabCurso`  VALUES ( "8","Dibujo Técnico I","2","1");
INSERT INTO `tabCurso`  VALUES ( "9","Educación Física I","1","1");


--
-- Tabel structure for table `tabCursoCatedratico`
--
DROP TABLE  IF EXISTS `tabCursoCatedratico`;
CREATE TABLE `tabCursoCatedratico` (
  `Id_CursoCatedratico` int(11) NOT NULL AUTO_INCREMENT,
  `Id_CicloEscolar` int(11) NOT NULL,
  `Id_Catedratico` int(11) NOT NULL,
  `Id_Curso` int(11) NOT NULL,
  PRIMARY KEY (`Id_CursoCatedratico`),
  KEY `Id_Catedratico` (`Id_Catedratico`),
  KEY `Id_Curso` (`Id_Curso`),
  KEY `Id_CicloEscolar` (`Id_CicloEscolar`),
  CONSTRAINT `tabCursoCatedratico_ibfk_1` FOREIGN KEY (`Id_Catedratico`) REFERENCES `tabCatedratico` (`Id_Catedratico`),
  CONSTRAINT `tabCursoCatedratico_ibfk_2` FOREIGN KEY (`Id_Curso`) REFERENCES `tabCurso` (`Id_Curso`),
  CONSTRAINT `tabCursoCatedratico_ibfk_3` FOREIGN KEY (`Id_CicloEscolar`) REFERENCES `tabCicloEscolar` (`Id_CicloEscolar`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

INSERT INTO `tabCursoCatedratico`  VALUES ( "1","3","1","1");
INSERT INTO `tabCursoCatedratico`  VALUES ( "2","3","3","2");
INSERT INTO `tabCursoCatedratico`  VALUES ( "3","3","3","3");
INSERT INTO `tabCursoCatedratico`  VALUES ( "4","3","2","4");
INSERT INTO `tabCursoCatedratico`  VALUES ( "7","3","1","5");
INSERT INTO `tabCursoCatedratico`  VALUES ( "8","3","1","8");
INSERT INTO `tabCursoCatedratico`  VALUES ( "9","3","7","6");
INSERT INTO `tabCursoCatedratico`  VALUES ( "11","3","7","7");


--
-- Tabel structure for table `tabDepartamento`
--
DROP TABLE  IF EXISTS `tabDepartamento`;
CREATE TABLE `tabDepartamento` (
  `Id_Departamento` int(11) NOT NULL AUTO_INCREMENT,
  `Nombre` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  PRIMARY KEY (`Id_Departamento`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

INSERT INTO `tabDepartamento`  VALUES ( "1","San Marcos");
INSERT INTO `tabDepartamento`  VALUES ( "2","Quetzaltenango");


--
-- Tabel structure for table `tabDetalleMensualidad`
--
DROP TABLE  IF EXISTS `tabDetalleMensualidad`;
CREATE TABLE `tabDetalleMensualidad` (
  `Id_DetalleMensualidad` int(11) NOT NULL AUTO_INCREMENT,
  `Id_Mensualidad` int(11) NOT NULL,
  `Id_Pago` int(11) NOT NULL,
  `Total` int(11) NOT NULL,
  PRIMARY KEY (`Id_DetalleMensualidad`),
  KEY `Id_Mensualidad` (`Id_Mensualidad`),
  KEY `Id_Pago` (`Id_Pago`),
  CONSTRAINT `tabDetalleMensualidad_ibfk_1` FOREIGN KEY (`Id_Mensualidad`) REFERENCES `tabMensualidad` (`Id_Mensualidad`),
  CONSTRAINT `tabDetalleMensualidad_ibfk_2` FOREIGN KEY (`Id_Pago`) REFERENCES `tabPago` (`Id_Pago`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

INSERT INTO `tabDetalleMensualidad`  VALUES ( "1","1","1","50");
INSERT INTO `tabDetalleMensualidad`  VALUES ( "2","2","2","25");
INSERT INTO `tabDetalleMensualidad`  VALUES ( "3","2","3","25");
INSERT INTO `tabDetalleMensualidad`  VALUES ( "4","3","4","25");
INSERT INTO `tabDetalleMensualidad`  VALUES ( "5","3","5","25");
INSERT INTO `tabDetalleMensualidad`  VALUES ( "6","4","1","50");
INSERT INTO `tabDetalleMensualidad`  VALUES ( "7","4","2","25");
INSERT INTO `tabDetalleMensualidad`  VALUES ( "8","5","3","25");
INSERT INTO `tabDetalleMensualidad`  VALUES ( "15","12","6","25");
INSERT INTO `tabDetalleMensualidad`  VALUES ( "16","13","7","25");
INSERT INTO `tabDetalleMensualidad`  VALUES ( "17","14","8","25");
INSERT INTO `tabDetalleMensualidad`  VALUES ( "20","17","8","25");
INSERT INTO `tabDetalleMensualidad`  VALUES ( "21","18","6","25");
INSERT INTO `tabDetalleMensualidad`  VALUES ( "22","19","7","25");
INSERT INTO `tabDetalleMensualidad`  VALUES ( "23","22","8","25");
INSERT INTO `tabDetalleMensualidad`  VALUES ( "25","23","6","25");
INSERT INTO `tabDetalleMensualidad`  VALUES ( "26","24","7","25");
INSERT INTO `tabDetalleMensualidad`  VALUES ( "27","25","9","25");
INSERT INTO `tabDetalleMensualidad`  VALUES ( "28","26","1","50");
INSERT INTO `tabDetalleMensualidad`  VALUES ( "29","26","2","25");


--
-- Tabel structure for table `tabEncargado`
--
DROP TABLE  IF EXISTS `tabEncargado`;
CREATE TABLE `tabEncargado` (
  `Id_Encargado` int(11) NOT NULL AUTO_INCREMENT,
  `DPI` varchar(20) COLLATE latin1_spanish_ci NOT NULL,
  `Nombre` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `Apellido` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `Ocupacion` varchar(50) COLLATE latin1_spanish_ci DEFAULT NULL,
  `Direccion` varchar(100) COLLATE latin1_spanish_ci DEFAULT NULL,
  `Id_Municipio` int(11) NOT NULL,
  `Telefono` int(11) DEFAULT NULL,
  PRIMARY KEY (`Id_Encargado`),
  KEY `Id_Municipio` (`Id_Municipio`),
  CONSTRAINT `tabEncargado_ibfk_1` FOREIGN KEY (`Id_Municipio`) REFERENCES `tabMunicipio` (`Id_Municipio`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

INSERT INTO `tabEncargado`  VALUES ( "1","5412 59451 1202","Jairo Enrique","Buitrago Lopez","Comerciante","6a. Avenida 4-21 Zona 1","2","77608508");
INSERT INTO `tabEncargado`  VALUES ( "2","7908 80135 1203","Francina Leonor","Quijano Ramirez","Oficios domesticos","3a. Calle 5-74 Zona 1, Callejón 3","4","87065812");
INSERT INTO `tabEncargado`  VALUES ( "3","8451 15845 1203","Gilberto Enrique","Benitez España","Comerciante","5a. Calle 1-58 Zona 1","2","58545894");
INSERT INTO `tabEncargado`  VALUES ( "4","1658 48120 4852","Jose Joaquin","Diaz Casas","Comerciante","6a. Calle 48-51 Zona 3","1","0");
INSERT INTO `tabEncargado`  VALUES ( "5","8745 94512 1203","Carlos Alfonso","Duarte Torres","Comerciante","8a. Calle 1-05 Zona 5","3","85424566");
INSERT INTO `tabEncargado`  VALUES ( "6","6589 48512 1203","Juan David","Figuero Cuesta","Comerciante","3a. Calle 4-52 Zona 3","4","8452108");
INSERT INTO `tabEncargado`  VALUES ( "7","6524 84512 6520","Oscar Armando","Garcia Angulo","Comerciante","1a. Avenida 1-25 Zona 3","2","780235678");
INSERT INTO `tabEncargado`  VALUES ( "8","2545 36584 1203","Rafael","Martines Gutierrez","Comerciante","3a. Avenida 45-2 Zona 1","2","54123697");
INSERT INTO `tabEncargado`  VALUES ( "9","4850 78541 9856","Gustavo Antonio","Martinez Estrada","Comerciante","6a. Calle 4-85 Zona 3","4","87452102");
INSERT INTO `tabEncargado`  VALUES ( "10","7895 50213 5461","Luis Pablo","Robles Mejia","Comerciante","5a Calle 15-02 Zona 1, Cantón San Sebastian-","2","77602158");
INSERT INTO `tabEncargado`  VALUES ( "11","8790 70456 1803","Juan Manuel","Orozco Barrios","Comerciante","3a Calle 4-85 Zona 3","4","78056482");


--
-- Tabel structure for table `tabEvaluacion`
--
DROP TABLE  IF EXISTS `tabEvaluacion`;
CREATE TABLE `tabEvaluacion` (
  `Id_Evaluacion` int(11) NOT NULL AUTO_INCREMENT,
  `Nombre` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  PRIMARY KEY (`Id_Evaluacion`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

INSERT INTO `tabEvaluacion`  VALUES ( "1","1ra. Evaluacion");
INSERT INTO `tabEvaluacion`  VALUES ( "2","2da. Evaluacion");
INSERT INTO `tabEvaluacion`  VALUES ( "3","3ra. Evaluacion");
INSERT INTO `tabEvaluacion`  VALUES ( "4","4ta. Evaluacion");
INSERT INTO `tabEvaluacion`  VALUES ( "5","Final");
INSERT INTO `tabEvaluacion`  VALUES ( "6","Recuperacion");


--
-- Tabel structure for table `tabGenero`
--
DROP TABLE  IF EXISTS `tabGenero`;
CREATE TABLE `tabGenero` (
  `Id_Genero` int(11) NOT NULL AUTO_INCREMENT,
  `Nombre` varchar(25) COLLATE latin1_spanish_ci NOT NULL,
  PRIMARY KEY (`Id_Genero`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

INSERT INTO `tabGenero`  VALUES ( "1","Femenino");
INSERT INTO `tabGenero`  VALUES ( "2","Masculino");


--
-- Tabel structure for table `tabGrado`
--
DROP TABLE  IF EXISTS `tabGrado`;
CREATE TABLE `tabGrado` (
  `Id_Grado` int(11) NOT NULL AUTO_INCREMENT,
  `Nombre` varchar(20) COLLATE latin1_spanish_ci NOT NULL,
  `Id_Carrera` int(11) NOT NULL,
  `Estado` tinyint(1) NOT NULL,
  PRIMARY KEY (`Id_Grado`),
  KEY `Id_Carrera` (`Id_Carrera`),
  CONSTRAINT `tabGrado_ibfk_1` FOREIGN KEY (`Id_Carrera`) REFERENCES `tabCarrera` (`Id_Carrera`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

INSERT INTO `tabGrado`  VALUES ( "1","Cuarto","1","1");
INSERT INTO `tabGrado`  VALUES ( "2","Quinto","1","1");
INSERT INTO `tabGrado`  VALUES ( "3","Sexto","1","1");


--
-- Tabel structure for table `tabListaCursos`
--
DROP TABLE  IF EXISTS `tabListaCursos`;
CREATE TABLE `tabListaCursos` (
  `Id_ListaCursos` int(11) NOT NULL AUTO_INCREMENT,
  `Id_Matricula` int(11) NOT NULL,
  `Id_CursoCatedratico` int(11) NOT NULL,
  `Id_Evaluacion` int(11) NOT NULL,
  `Nota` decimal(3,0) NOT NULL,
  PRIMARY KEY (`Id_ListaCursos`),
  KEY `Id_Matricula` (`Id_Matricula`),
  KEY `Id_Evaluacion` (`Id_Evaluacion`),
  KEY `Id_CursoCatedratico` (`Id_CursoCatedratico`),
  CONSTRAINT `tabListaCursos_ibfk_1` FOREIGN KEY (`Id_Matricula`) REFERENCES `tabMatricula` (`Id_Matricula`),
  CONSTRAINT `tabListaCursos_ibfk_2` FOREIGN KEY (`Id_Evaluacion`) REFERENCES `tabEvaluacion` (`Id_Evaluacion`),
  CONSTRAINT `tabListaCursos_ibfk_3` FOREIGN KEY (`Id_CursoCatedratico`) REFERENCES `tabCursoCatedratico` (`Id_CursoCatedratico`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

INSERT INTO `tabListaCursos`  VALUES ( "21","1","1","1","75");
INSERT INTO `tabListaCursos`  VALUES ( "22","3","1","1","61");
INSERT INTO `tabListaCursos`  VALUES ( "23","4","1","1","60");
INSERT INTO `tabListaCursos`  VALUES ( "24","5","1","1","83");
INSERT INTO `tabListaCursos`  VALUES ( "25","8","1","1","70");


--
-- Tabel structure for table `tabMatricula`
--
DROP TABLE  IF EXISTS `tabMatricula`;
CREATE TABLE `tabMatricula` (
  `Id_Matricula` int(11) NOT NULL AUTO_INCREMENT,
  `Clave` int(11) DEFAULT NULL,
  `Id_Alumno` int(11) NOT NULL,
  `Id_CicloEscolar` int(11) NOT NULL,
  `Id_Seccion` int(11) NOT NULL,
  `Estado` tinyint(1) NOT NULL,
  `Observaciones` varchar(200) COLLATE latin1_spanish_ci DEFAULT NULL,
  PRIMARY KEY (`Id_Matricula`),
  KEY `Id_Alumno` (`Id_Alumno`),
  KEY `Id_Seccion` (`Id_Seccion`),
  KEY `Id_CicloEscolar` (`Id_CicloEscolar`),
  CONSTRAINT `tabMatricula_ibfk_1` FOREIGN KEY (`Id_Alumno`) REFERENCES `tabAlumnoInscripcion` (`Id_Alumno`),
  CONSTRAINT `tabMatricula_ibfk_2` FOREIGN KEY (`Id_Seccion`) REFERENCES `tabSeccion` (`Id_Seccion`),
  CONSTRAINT `tabMatricula_ibfk_3` FOREIGN KEY (`Id_CicloEscolar`) REFERENCES `tabCicloEscolar` (`Id_CicloEscolar`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

INSERT INTO `tabMatricula`  VALUES ( "1","1","1","3","1","1","");
INSERT INTO `tabMatricula`  VALUES ( "2","1","2","3","2","1","");
INSERT INTO `tabMatricula`  VALUES ( "3","2","6","3","1","1","");
INSERT INTO `tabMatricula`  VALUES ( "4","3","7","3","1","1","");
INSERT INTO `tabMatricula`  VALUES ( "5","4","8","3","1","1","");
INSERT INTO `tabMatricula`  VALUES ( "6","2","9","3","2","1","");
INSERT INTO `tabMatricula`  VALUES ( "7","3","10","3","2","1","");
INSERT INTO `tabMatricula`  VALUES ( "8","5","11","3","1","1","");


--
-- Tabel structure for table `tabMensualidad`
--
DROP TABLE  IF EXISTS `tabMensualidad`;
CREATE TABLE `tabMensualidad` (
  `Id_Mensualidad` int(11) NOT NULL AUTO_INCREMENT,
  `Id_CicloEscolar` int(11) NOT NULL,
  `Id_Matricula` int(11) NOT NULL,
  `Fecha` date NOT NULL,
  `Direccion` varchar(100) COLLATE latin1_spanish_ci DEFAULT NULL,
  `Observaciones` varchar(150) COLLATE latin1_spanish_ci DEFAULT NULL,
  `Total_Final` int(11) NOT NULL,
  `Estado` tinyint(1) NOT NULL,
  PRIMARY KEY (`Id_Mensualidad`),
  KEY `Id_Matricula` (`Id_Matricula`),
  KEY `Id_CicloEscolar` (`Id_CicloEscolar`),
  CONSTRAINT `tabMensualidad_ibfk_1` FOREIGN KEY (`Id_Matricula`) REFERENCES `tabMatricula` (`Id_Matricula`),
  CONSTRAINT `tabMensualidad_ibfk_2` FOREIGN KEY (`Id_CicloEscolar`) REFERENCES `tabCicloEscolar` (`Id_CicloEscolar`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

INSERT INTO `tabMensualidad`  VALUES ( "1","3","1","2014-05-08","Ciudad","","50","1");
INSERT INTO `tabMensualidad`  VALUES ( "2","3","1","2014-05-08","Ciudad","","50","1");
INSERT INTO `tabMensualidad`  VALUES ( "3","3","1","2014-05-08","Ciudad","Se le olvido dejar el dinero xD","50","1");
INSERT INTO `tabMensualidad`  VALUES ( "4","3","2","2014-05-08","Ciudad","","75","1");
INSERT INTO `tabMensualidad`  VALUES ( "5","3","2","2014-05-09","Ciudad","","25","1");
INSERT INTO `tabMensualidad`  VALUES ( "6","3","2","2014-05-16","Ciudad","","25","0");
INSERT INTO `tabMensualidad`  VALUES ( "7","3","1","2014-05-18","Ciudad","","25","0");
INSERT INTO `tabMensualidad`  VALUES ( "8","3","1","2014-05-18","Ciudad","","25","0");
INSERT INTO `tabMensualidad`  VALUES ( "9","3","1","2014-05-18","Ciudad","","25","0");
INSERT INTO `tabMensualidad`  VALUES ( "10","3","1","2014-05-18","Ciudad","","25","0");
INSERT INTO `tabMensualidad`  VALUES ( "11","3","1","2014-05-18","Ciudad","","25","0");
INSERT INTO `tabMensualidad`  VALUES ( "12","3","1","2014-05-18","Ciudad","","25","0");
INSERT INTO `tabMensualidad`  VALUES ( "13","3","1","2014-05-18","Ciudad","","25","0");
INSERT INTO `tabMensualidad`  VALUES ( "14","3","1","2014-05-18","Ciudad","","25","0");
INSERT INTO `tabMensualidad`  VALUES ( "15","3","1","2014-05-18","Ciudad","","25","0");
INSERT INTO `tabMensualidad`  VALUES ( "16","3","1","2014-05-18","Ciudad","","25","0");
INSERT INTO `tabMensualidad`  VALUES ( "17","3","1","2014-05-18","Ciudad","","25","0");
INSERT INTO `tabMensualidad`  VALUES ( "18","3","1","2014-05-24","Ciudad","","25","0");
INSERT INTO `tabMensualidad`  VALUES ( "19","3","1","2014-05-24","Ciudad","","25","0");
INSERT INTO `tabMensualidad`  VALUES ( "20","3","1","2014-05-24","Ciudad","","25","0");
INSERT INTO `tabMensualidad`  VALUES ( "22","3","1","2014-05-24","Ciudad","","25","1");
INSERT INTO `tabMensualidad`  VALUES ( "23","3","1","2014-05-24","Ciudad","","25","1");
INSERT INTO `tabMensualidad`  VALUES ( "24","3","1","2014-05-26","Ciudad","","25","1");
INSERT INTO `tabMensualidad`  VALUES ( "25","3","1","2014-05-26","Ciudad","","25","1");
INSERT INTO `tabMensualidad`  VALUES ( "26","3","5","2014-05-26","Ciudad","","75","1");


--
-- Tabel structure for table `tabMunicipio`
--
DROP TABLE  IF EXISTS `tabMunicipio`;
CREATE TABLE `tabMunicipio` (
  `Id_Municipio` int(11) NOT NULL AUTO_INCREMENT,
  `Nombre` varchar(75) COLLATE latin1_spanish_ci NOT NULL,
  `Id_Departamento` int(11) NOT NULL,
  PRIMARY KEY (`Id_Municipio`),
  KEY `Id_Departamento` (`Id_Departamento`),
  CONSTRAINT `tabMunicipio_ibfk_1` FOREIGN KEY (`Id_Departamento`) REFERENCES `tabDepartamento` (`Id_Departamento`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

INSERT INTO `tabMunicipio`  VALUES ( "1","San Pedro Sacatepequez","1");
INSERT INTO `tabMunicipio`  VALUES ( "2","San Marcos","1");
INSERT INTO `tabMunicipio`  VALUES ( "3","Quetzaltenango","2");
INSERT INTO `tabMunicipio`  VALUES ( "4","San Antonio Sacatepequez","1");


--
-- Tabel structure for table `tabPago`
--
DROP TABLE  IF EXISTS `tabPago`;
CREATE TABLE `tabPago` (
  `Id_Pago` int(11) NOT NULL AUTO_INCREMENT,
  `Nombre` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `Precio` int(11) NOT NULL,
  PRIMARY KEY (`Id_Pago`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

INSERT INTO `tabPago`  VALUES ( "1","Inscripcion","50");
INSERT INTO `tabPago`  VALUES ( "2","Enero","25");
INSERT INTO `tabPago`  VALUES ( "3","Febrero","25");
INSERT INTO `tabPago`  VALUES ( "4","Marzo","25");
INSERT INTO `tabPago`  VALUES ( "5","Abril","25");
INSERT INTO `tabPago`  VALUES ( "6","Mayo","25");
INSERT INTO `tabPago`  VALUES ( "7","Junio","25");
INSERT INTO `tabPago`  VALUES ( "8","Julio","25");
INSERT INTO `tabPago`  VALUES ( "9","Agosto","25");
INSERT INTO `tabPago`  VALUES ( "10","Septiembre","25");
INSERT INTO `tabPago`  VALUES ( "11","Octubre","25");


--
-- Tabel structure for table `tabPersonalAdmin`
--
DROP TABLE  IF EXISTS `tabPersonalAdmin`;
CREATE TABLE `tabPersonalAdmin` (
  `Id_PersonalAdmin` int(11) NOT NULL AUTO_INCREMENT,
  `Nombre` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `Apellido` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `Id_Genero` int(11) NOT NULL,
  `Fecha_Nacimiento` date NOT NULL,
  `Direccion` varchar(100) COLLATE latin1_spanish_ci DEFAULT NULL,
  `Id_Municipio` int(11) NOT NULL,
  `Telefono` int(11) DEFAULT NULL,
  PRIMARY KEY (`Id_PersonalAdmin`),
  KEY `Id_Municipio` (`Id_Municipio`),
  KEY `Id_Genero` (`Id_Genero`),
  CONSTRAINT `tabPersonalAdmin_ibfk_1` FOREIGN KEY (`Id_Municipio`) REFERENCES `tabMunicipio` (`Id_Municipio`),
  CONSTRAINT `tabPersonalAdmin_ibfk_2` FOREIGN KEY (`Id_Genero`) REFERENCES `tabGenero` (`Id_Genero`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

INSERT INTO `tabPersonalAdmin`  VALUES ( "1","Manuel Antonio","Ballen Vanegas","2","1970-11-13","4a. Avenida 5-65 Zona 1","1","77608495");
INSERT INTO `tabPersonalAdmin`  VALUES ( "3","Mario Cristian","Orozco Fuentes","2","1975-05-13","1a. Calle 1-74 Zona 3","1","57012485");
INSERT INTO `tabPersonalAdmin`  VALUES ( "4","Elena Marisol","Fuentes Perez","1","1980-02-11","3a. Avenida 7-50 Zona 2","4","77608194");


--
-- Tabel structure for table `tabPersonalUsuario`
--
DROP TABLE  IF EXISTS `tabPersonalUsuario`;
CREATE TABLE `tabPersonalUsuario` (
  `Id_PersonalUsuario` int(11) NOT NULL AUTO_INCREMENT,
  `Id_PersonalAdmin` int(11) NOT NULL,
  `Id_Usuario` int(11) NOT NULL,
  PRIMARY KEY (`Id_PersonalUsuario`),
  KEY `Id_Usuario` (`Id_Usuario`),
  KEY `Id_PersonalAdmin` (`Id_PersonalAdmin`),
  CONSTRAINT `tabPersonalUsuario_ibfk_1` FOREIGN KEY (`Id_Usuario`) REFERENCES `tabUsuario` (`Id_Usuario`),
  CONSTRAINT `tabPersonalUsuario_ibfk_2` FOREIGN KEY (`Id_PersonalAdmin`) REFERENCES `tabPersonalAdmin` (`Id_PersonalAdmin`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

INSERT INTO `tabPersonalUsuario`  VALUES ( "1","1","1");
INSERT INTO `tabPersonalUsuario`  VALUES ( "2","3","10");
INSERT INTO `tabPersonalUsuario`  VALUES ( "3","4","11");


--
-- Tabel structure for table `tabRolSistema`
--
DROP TABLE  IF EXISTS `tabRolSistema`;
CREATE TABLE `tabRolSistema` (
  `Id_RolSistema` int(11) NOT NULL AUTO_INCREMENT,
  `Nombre` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `Estado` tinyint(1) NOT NULL,
  PRIMARY KEY (`Id_RolSistema`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

INSERT INTO `tabRolSistema`  VALUES ( "1","Estudiante","1");
INSERT INTO `tabRolSistema`  VALUES ( "2","Catedratico","1");
INSERT INTO `tabRolSistema`  VALUES ( "3","Secretaria","1");
INSERT INTO `tabRolSistema`  VALUES ( "4","Direccion","1");


--
-- Tabel structure for table `tabSeccion`
--
DROP TABLE  IF EXISTS `tabSeccion`;
CREATE TABLE `tabSeccion` (
  `Id_Seccion` int(11) NOT NULL AUTO_INCREMENT,
  `Id_Grado` int(11) NOT NULL,
  `Nombre` char(1) COLLATE latin1_spanish_ci NOT NULL,
  `Estado` tinyint(1) NOT NULL,
  PRIMARY KEY (`Id_Seccion`),
  KEY `Id_Grado` (`Id_Grado`),
  CONSTRAINT `tabSeccion_ibfk_1` FOREIGN KEY (`Id_Grado`) REFERENCES `tabGrado` (`Id_Grado`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

INSERT INTO `tabSeccion`  VALUES ( "1","1","A","1");
INSERT INTO `tabSeccion`  VALUES ( "2","1","B","1");


--
-- Tabel structure for table `tabUsuario`
--
DROP TABLE  IF EXISTS `tabUsuario`;
CREATE TABLE `tabUsuario` (
  `Id_Usuario` int(11) NOT NULL AUTO_INCREMENT,
  `Nombre` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `Contrasena` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `Id_RolSistema` int(11) NOT NULL,
  `Estado` tinyint(1) NOT NULL,
  PRIMARY KEY (`Id_Usuario`),
  KEY `Id_RolSistema` (`Id_RolSistema`),
  CONSTRAINT `tabUsuario_ibfk_1` FOREIGN KEY (`Id_RolSistema`) REFERENCES `tabRolSistema` (`Id_RolSistema`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

INSERT INTO `tabUsuario`  VALUES ( "1","manuel","123","4","1");
INSERT INTO `tabUsuario`  VALUES ( "2","carlosmanuel","1234","1","1");
INSERT INTO `tabUsuario`  VALUES ( "3","ismaelenrique","1234","2","1");
INSERT INTO `tabUsuario`  VALUES ( "4","alvaroantonio","963397","2","1");
INSERT INTO `tabUsuario`  VALUES ( "5","alvaroa","705888","2","1");
INSERT INTO `tabUsuario`  VALUES ( "6","gabymar","12345","1","1");
INSERT INTO `tabUsuario`  VALUES ( "7","jorgem","2GQ8IHLV","1","1");
INSERT INTO `tabUsuario`  VALUES ( "8","gustavodany","WX8DT29P","1","1");
INSERT INTO `tabUsuario`  VALUES ( "9","jbamaca","941350","2","1");
INSERT INTO `tabUsuario`  VALUES ( "10","mcristian","214943","4","1");
INSERT INTO `tabUsuario`  VALUES ( "11","emarisol","123","3","1");
INSERT INTO `tabUsuario`  VALUES ( "12","lalberto","53FZ7EIG","1","1");
INSERT INTO `tabUsuario`  VALUES ( "13","cris","DRTMF95W","1","1");
INSERT INTO `tabUsuario`  VALUES ( "14","jcarlos25","MOSTA5YN","1","1");
INSERT INTO `tabUsuario`  VALUES ( "15","rosaem","JQXLVHY9","1","1");


--
-- Tabel structure for table `tabUsuarioAlumno`
--
DROP TABLE  IF EXISTS `tabUsuarioAlumno`;
CREATE TABLE `tabUsuarioAlumno` (
  `Id_UsuarioAlumno` int(11) NOT NULL AUTO_INCREMENT,
  `Id_Usuario` int(11) NOT NULL,
  `Id_Alumno` int(11) NOT NULL,
  PRIMARY KEY (`Id_UsuarioAlumno`),
  KEY `Id_Alumno` (`Id_Alumno`),
  KEY `Id_Usuario` (`Id_Usuario`),
  CONSTRAINT `tabUsuarioAlumno_ibfk_1` FOREIGN KEY (`Id_Alumno`) REFERENCES `tabAlumnoInscripcion` (`Id_Alumno`),
  CONSTRAINT `tabUsuarioAlumno_ibfk_2` FOREIGN KEY (`Id_Usuario`) REFERENCES `tabUsuario` (`Id_Usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

INSERT INTO `tabUsuarioAlumno`  VALUES ( "1","2","1");
INSERT INTO `tabUsuarioAlumno`  VALUES ( "2","6","2");
INSERT INTO `tabUsuarioAlumno`  VALUES ( "3","7","6");
INSERT INTO `tabUsuarioAlumno`  VALUES ( "4","8","7");
INSERT INTO `tabUsuarioAlumno`  VALUES ( "5","12","8");
INSERT INTO `tabUsuarioAlumno`  VALUES ( "6","13","9");
INSERT INTO `tabUsuarioAlumno`  VALUES ( "7","14","10");
INSERT INTO `tabUsuarioAlumno`  VALUES ( "8","15","11");


SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
